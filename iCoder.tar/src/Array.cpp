#include <iostream>

#include "../header/Array.hpp"
#include "../namespace/header/cod_array.hpp"