#ifndef ARRAY_HPP
#define ARRAY_HPP

#include <string>

#endif