#ifndef SETTINGS_HPP
#define SETTINGS_HPP

#include <iostream>
#include <sstream>
#include <windows.h>
#include "iCoder.hpp"

/** FUNCTION PROTOTYPES **/
void settings();
void settings_controller(char ch);
void change_menu_speed();

#endif