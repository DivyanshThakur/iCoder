#ifndef SETTINGS_HPP
#define SETTINGS_HPP

/** FUNCTION PROTOTYPES **/
void settings();
void settings_controller(char ch);
void change_text_anime_speed();

#endif