#include "../header/cod_array.hpp"

// code for arrays