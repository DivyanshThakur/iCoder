#ifndef COD_ARRAY_HPP
#define COD_ARRAY_HPP

namespace cod
{
class array
{
private:
    int i;

public:
};
} // namespace cod

#endif